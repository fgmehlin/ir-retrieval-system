package ch.ethz.dal.tinyir.util

import math.Numeric

object MapHelper {
  
  
}