package ch.ethz.dal.tinyir.shingling

//import ch.ethz.dal.tinyir.collection._

object NearDuplicates {

}

